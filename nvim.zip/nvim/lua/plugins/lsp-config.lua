return {
    {
        "mason-org/mason-lspconfig.nvim",
        opts = {},
        config = function()
            require("mason-lspconfig").setup({
                automatic_enable = {
                    exclude = {
                        "jdtls",
                    },
                },
                ensure_installed = {
                    "lua_ls",
                    "html",
                    "cssls",
                    "ts_ls",
                    "pyright",
                    "tombi",
                    "tailwindcss",
                    "jdtls",
                },
            })
        end,
        dependencies = {
            { "mason-org/mason.nvim", opts = {} },
            {
                "neovim/nvim-lspconfig",
                config = function()
                    require("neoconf").setup({})
                    -- require("lspconfig").rust_analyzer.setup({
                    --     on_attach = function(_, bufnr)
                    --         vim.lsp.inlay_hint.enable(true, { bufnr })
                    --     end,
                    --     settings = {
                    --         ["rust_analyzer"] = {
                    --             cargo = {
                    --                 allFeatures = true,
                    --             },
                    --             checkOnSave = {
                    --                 command = "clippy",
                    --             },
                    --         },
                    --     },
                    -- })
                end,
            },
        },
    },
    {
        "WhoIsSethDaniel/mason-tool-installer.nvim",
        config = function()
            require("mason-tool-installer").setup({
                ensure_installed = {
                    "stylua",
                    "prettier",
                    "black",
                },
            })
        end,
    },
}
