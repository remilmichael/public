return {
    {
        "nvim-neo-tree/neo-tree.nvim",
        branch = "v3.x",
        dependencies = {
            "nvim-lua/plenary.nvim",
            "MunifTanjim/nui.nvim",
            "nvim-tree/nvim-web-devicons", -- optional, but recommended
        },
        lazy = false,             -- neo-tree will lazily load itself
        config = function()
            require("neo-tree").setup({
                close_if_last_window = false,
                window = {
                    position = "float",
                },
                filesystem = {
                    filtered_items = {
                        visible = true, -- show filtered (hidden) items as "dimmed"
                        hide_dotfiles = false, -- do NOT hide dotfiles
                        hide_gitignored = false, -- do NOT hide .gitignored files
                        hide_hidden = false, -- do NOT hide "hidden" attribute files
                    },
                    follow_current_file = {
                        enabled = true,
                    },
                    auto_expand = true,
                },
            })
        end,
    },
}
