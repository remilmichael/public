return {
	"nvim-treesitter/nvim-treesitter",
	branch = "main",
	lazy = false,
	build = ":TSUpdate",
	--	config = function()
	--		local config = require("nvim-treesitter")
	--		config.install({
	--            "rust", "javascript", "python"
	--        })
	--	end,
}
