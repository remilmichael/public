vim.cmd("set expandtab")
vim.cmd("set tabstop=4")
vim.cmd("set shiftwidth=4")
vim.g.mapleader = " "
vim.g.maplocalleader = "\\"
vim.opt.relativenumber = true
vim.cmd("syntax on")
vim.o.termguicolors = true
vim.o.foldcolumn = "1" -- '0' is not bad
vim.o.foldlevel = 99 -- Using ufo provider need a large value, feel free to decrease the value
vim.o.foldlevelstart = 99
vim.o.foldenable = true

local double_border = {
	{ "╔", "FloatBorder" },
	{ "═", "FloatBorder" },
	{ "╗", "FloatBorder" },
	{ "║", "FloatBorder" },
	{ "╝", "FloatBorder" },
	{ "═", "FloatBorder" },
	{ "╚", "FloatBorder" },
	{ "║", "FloatBorder" },
}

vim.lsp.handlers["textDocument/hover"] = vim.lsp.with(vim.lsp.handlers.hover, {
	border = double_border,
	max_width = 80,
})

-- shows the errors, warning, and hints beside the line instead of just W, E, H, etc.
vim.diagnostic.config({
	virtual_text = true,
	virtual_lines = false,
	underline = false,
	signs = true,
	float = {
		border = "rounded", -- you can use "single", "double", "shadow", etc.
		source = "always", -- show the source in diagnostics
		header = "",
		prefix = function(diagnostic)
			local icons = {
				[vim.diagnostic.severity.ERROR] = " ",
				[vim.diagnostic.severity.WARN] = " ",
				[vim.diagnostic.severity.HINT] = "󰌶 ",
				[vim.diagnostic.severity.INFO] = " ",
			}
			return icons[diagnostic.severity] or ""
		end,
	},
})

vim.api.nvim_set_keymap("n", "<Up>", "<Nop>", { noremap = true, silent = true })
vim.api.nvim_set_keymap("n", "<Down>", "<Nop>", { noremap = true, silent = true })
vim.api.nvim_set_keymap("n", "<Left>", "<Nop>", { noremap = true, silent = true })
vim.api.nvim_set_keymap("n", "<Right>", "<Nop>", { noremap = true, silent = true })

require("config.lazy")
require("keymaps.init")
