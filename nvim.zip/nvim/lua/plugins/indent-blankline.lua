return {
	"lukas-reineke/indent-blankline.nvim",
	main = "ibl",
	---@module "ibl"
	---@type ibl.config
	opts = {},
	config = function()
		require("ibl").setup({
			indent = {
				 char ="│",
			},
		})
        vim.api.nvim_set_hl(0, "IblIndent", { fg = "#444444", nocombine = true })
	end,
}
