return {
    {
        "tinted-theming/tinted-nvim",
        config = function()
            local gruvbox_dark_hard = {
                base00 = "#1d2021",
                base01 = "#3c3836",
                base02 = "#504945",
                base03 = "#665c54",
                base04 = "#bdae93",
                base05 = "#d5c4a1",
                base06 = "#ebdbb2",
                base07 = "#fbf1c7",
                base08 = "#fb4934",
                base09 = "#fe8019",
                base0A = "#fabd2f",
                base0B = "#b8bb26",
                base0C = "#8ec07c",
                base0D = "#83a598",
                base0E = "#d3869b",
                base0F = "#d65d0e",
            }

            local custom_palette = vim.tbl_extend("force", gruvbox_dark_hard, {
                base08 = "#c08060",
                base09 = "#689D6A",
            })

            require("tinted-colorscheme").setup(custom_palette)
            -- Make comments more prominent
            local bools = vim.api.nvim_get_hl(0, { name = "Boolean" })
            vim.api.nvim_set_hl(0, "Comment", bools)
        end,
    },
}
