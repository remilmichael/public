local builtin = require("telescope.builtin")

vim.keymap.set("n", "<leader>ff", function()
	builtin.find_files({ search_files = { "." } })
end, { desc = "Telescope find files" })

vim.keymap.set("n", "<leader>fg", function()
	builtin.live_grep({ search_dirs = { "." } })
end, { desc = "Telescope live grep within current directory" })

vim.keymap.set("n", "<leader>fb", builtin.buffers, { desc = "Telescope buffers" })
vim.keymap.set("n", "<leader>fh", builtin.help_tags, { desc = "Telescope help tags" })

vim.keymap.set("n", "<leader>dd", function()
	require("telescope.builtin").diagnostics({ bufnr = 0 })
end, { desc = "Diagnostics for current file" })

vim.keymap.set("n", "<leader>dw", function()
	require("telescope.builtin").diagnostics()
end, { desc = "Diagnostics for the workspace" })

