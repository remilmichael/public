return {
    --    {
    --        "catppuccin/nvim",
    --        name = "catppuccin",
    --        priority = 1000,
    --        config = function()
    --            require("catppuccin").setup({
    --                vim.cmd.colorscheme "catppuccin",
    --                flavour = "macchiato",
    --            })
    --        end,
    --    },
    --    {
    --        "folke/tokyonight.nvim",
    --        lazy = false,
    --        priority = 1000,
    --        opts = {},
    --        config = function()
    --            require("tokyonight").setup({
    --                vim.cmd[[colorscheme tokyonight-storm]]
    --            })
    --        end,
    --    },
    --    {
    --        "ellisonleao/gruvbox.nvim",
    --        priority = 1000,
    --        config = function()
    --            require("gruvbox").setup({
    --                vim.o.background == "dark",
    --                vim.cmd([[colorscheme gruvbox]]),
    --            })
    --        end,
    --    },
    {
        "rebelot/kanagawa.nvim",
        priority = 1000,
        config = function()
            require("kanagawa").setup({
                vim.cmd("colorscheme kanagawa"),
            })
        end,
    },
}
