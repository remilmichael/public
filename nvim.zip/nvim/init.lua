require("config.vim-options")
require("config.lazy")
require("keymaps.init")
