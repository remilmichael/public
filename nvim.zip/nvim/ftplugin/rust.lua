local function find_nearest_cargo_toml(start_path)
	local path_sep = package.config:sub(1, 1) -- get OS-specific path separator
	local dir = vim.fn.fnamemodify(start_path, ":p:h")

	while dir ~= "/" and dir ~= "" do
		local cargo_toml = dir .. path_sep .. "Cargo.toml"
		if vim.fn.filereadable(cargo_toml) == 1 then
			return cargo_toml
		end
		dir = vim.fn.fnamemodify(dir, ":h")
	end

	return nil
end

vim.keymap.set("n", "<leader>gf", function()
  -- Save current file
  vim.cmd("write")

  -- Get full path of the current file
  local file = vim.fn.expand("%:p")

  -- Find the nearest Cargo.toml from the current file's directory
  local cargo_toml = find_nearest_cargo_toml(file)
  if not cargo_toml then
    vim.notify("Could not find Cargo.toml in parent directories.", vim.log.levels.ERROR)
    return
  end

  -- Format with cargo fmt using --quiet
  local cmd = string.format("cargo fmt --quiet --manifest-path %s -- %s", cargo_toml, file)
  vim.fn.system(cmd)

  -- Reload buffer after formatting
  vim.cmd("edit")
end, { buffer = true, desc = "Format current Rust file with rustfmt" })
