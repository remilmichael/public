vim.keymap.set("n", "<C-n>", ":Neotree toggle<CR>", { noremap = true })

vim.keymap.set("n", "<leader>ln", function()
    vim.wo.number = not vim.wo.number
    vim.wo.relativenumber = not vim.wo.relativenumber
end, { desc = "Toggle line numbers" })

vim.keymap.set("n", "<leader>nh", ":noh<CR>", { silent = true, desc = "Disable highlighting" })
