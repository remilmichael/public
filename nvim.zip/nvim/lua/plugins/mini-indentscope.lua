return {
	"nvim-mini/mini.indentscope",
	version = false,
	config = function()
		local indentscope = require("mini.indentscope")
		indentscope.setup({
			draw = {
				animation = indentscope.gen_animation.none(),
			},
			symbol = "│",
		})
		vim.api.nvim_set_hl(0, "MiniIndentscopeSymbol", { fg = "#444444", bold = false })
	end,
}
